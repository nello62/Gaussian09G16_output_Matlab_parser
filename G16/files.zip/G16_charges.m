function ch = G16_charges(filename, varargin)
% G16_CHARGES  Estrae le cariche di Mulliken (e APT se presenti) da un
%              and renders them as colour-coded labels on the 3D molecular structure.
%
%   ch = G16_CHARGES(filename)
%   ch = G16_CHARGES(filename, Name, Value, ...)
%
%   Optional parameters:
%       'type'        - charge type: 'Mulliken' (default) | 'APT'
%       'mode'        - 'atom'   one label per atom (default)
%                       'heavy'  hydrogen charges summed onto bonded heavy atoms
%       'plot'        - true  renders labels on the 3D molecule (default: true)
%       'AtomScale'   - CPK sphere scale factor (default: 0.35)
%       'BondTol'     - bond detection tolerance (default: 1.30)
%       'FontSize'    - label font size in points (default: 8)
%       'ColorScale'  - 'RdBu'  blue=negative / red=positive (default)
%                       'none'  black text for all labels
%       'threshold'   - hide labels with |q| < threshold (default: 0)
%
%   OUTPUT  struct ch with fields:
%       .symbols      {Natoms x 1}   atomic symbols
%       .charges      [Natoms x 1]   per-atom charges (e)
%       .charges_H    [Nheavy x 1]   H-summed charges on heavy atoms ([] if not computed)
%       .sum_q        double         sum of all charges (should be ≈ 0 for neutral molecules)
%       .type         char           charge type used: 'Mulliken' or 'APT'
%       .Natoms       int            number of atoms
%       .filename     char           source file path
%
%   Example:
%       ch = G16_charges('V_E00t.out');
%       ch = G16_charges('V_E00t.out', 'mode', 'heavy', 'threshold', 0.05);
%       ch = G16_charges('V_E00t.out', 'type', 'APT', 'ColorScale', 'none');

% -------------------------------------------------------------------------
p = inputParser;
addRequired(p,  'filename',   @ischar);
addParameter(p, 'type',       'Mulliken', @ischar);
addParameter(p, 'mode',       'atom',     @ischar);
addParameter(p, 'plot',       true,       @islogical);
addParameter(p, 'AtomScale',  0.35,       @isnumeric);
addParameter(p, 'BondTol',    1.30,       @isnumeric);
addParameter(p, 'FontSize',   8,          @isnumeric);
addParameter(p, 'ColorScale', 'RdBu',     @ischar);
addParameter(p, 'threshold',  0,          @isnumeric);
parse(p, filename, varargin{:});

charge_type = p.Results.type;
mode        = lower(p.Results.mode);
do_plot     = p.Results.plot;
atom_scale  = p.Results.AtomScale;
bond_tol    = p.Results.BondTol;
fsize       = p.Results.FontSize;
cscale      = p.Results.ColorScale;
thr         = p.Results.threshold;

% -------------------------------------------------------------------------
% Read file
% -------------------------------------------------------------------------
if ~isfile(filename)
    error('G16_charges: file not found: %s', filename);
end
fid  = fopen(filename, 'r');
raw  = fread(fid, '*char')';
fclose(fid);
lines = strsplit(raw, newline);
N = numel(lines);

% -------------------------------------------------------------------------
% Parse charges (takes LAST occurrence)
% -------------------------------------------------------------------------
% Build the header string to search for
header_pat = [charge_type, ' charges:'];

syms_atom    = {};
q_atom       = [];
syms_heavy   = {};
q_heavy      = [];

k = 1;
while k <= N
    ln = strtrim(lines{k});

    % ── per-atom charge block
    if strcmpi(ln, header_pat)
        k = k + 2;   % salta "               1"
        tmp_syms = {};
        tmp_q    = [];
        while k <= N
            ln2 = strtrim(lines{k});
            % End of block when a "Sum of..." line or blank line is found
            if isempty(ln2) || ~isempty(strfind(ln2, 'Sum of'))
                break
            end
            % Formato: "  1  C  -0.087530"
            tok = sscanf(ln2, '%d %s %f');
            % sscanf with %s reads one char at a time in mixed-type lines;
            % regexp is more reliable here
            m = regexp(ln2, '^\s*\d+\s+([A-Za-z]+)\s+([-\d.]+)', 'tokens', 'once');
            if ~isempty(m)
                tmp_syms{end+1} = m{1};      %#ok<AGROW>
                tmp_q(end+1)    = str2double(m{2}); %#ok<AGROW>
            end
            k = k + 1;
        end
        % Overwrite previous data: last occurrence in file is used
        if ~isempty(tmp_q)
            syms_atom = tmp_syms;
            q_atom    = tmp_q(:);
        end
        continue
    end

    % ── H-summed charges block
    if ~isempty(strfind(ln, [charge_type, ' charges with hydrogens summed']))
        k = k + 2;   % salta "               1"
        tmp_syms = {};
        tmp_q    = [];
        while k <= N
            ln2 = strtrim(lines{k});
            if isempty(ln2) || ~isempty(strfind(ln2, 'Sum of')) || ...
               ~isempty(strfind(ln2, 'charges'))
                break
            end
            m = regexp(ln2, '^\s*\d+\s+([A-Za-z]+)\s+([-\d.]+)', 'tokens', 'once');
            if ~isempty(m)
                tmp_syms{end+1} = m{1};      %#ok<AGROW>
                tmp_q(end+1)    = str2double(m{2}); %#ok<AGROW>
            end
            k = k + 1;
        end
        if ~isempty(tmp_q)
            syms_heavy = tmp_syms;
            q_heavy    = tmp_q(:);
        end
        continue
    end

    k = k + 1;
end

if isempty(q_atom)
    error('G16_charges: no "%s" charges found in %s', charge_type, filename);
end

% -------------------------------------------------------------------------
% Select which charge set to display (per-atom or H-summed)
% -------------------------------------------------------------------------
switch mode
    case 'atom'
        syms_use = syms_atom;
        q_use    = q_atom;
    case 'heavy'
        if isempty(q_heavy)
            warning('G16_charges: H-summed charges not found; falling back to per-atom charges.');
            syms_use = syms_atom;
            q_use    = q_atom;
        else
            syms_use = syms_heavy;
            q_use    = q_heavy;
        end
    otherwise
        error('G16_charges: mode must be ''atom'' or ''heavy''.');
end

% -------------------------------------------------------------------------
% Assemble output struct
% -------------------------------------------------------------------------
ch.symbols   = syms_atom(:);
ch.charges   = q_atom;
ch.charges_H = q_heavy;
ch.sum_q     = sum(q_atom);
ch.type      = charge_type;
ch.Natoms    = numel(q_atom);
ch.filename  = filename;

% Print charge table to console
fprintf('\n── G16_charges (%s, %s): %s ──\n', charge_type, mode, filename);
fprintf('  %4s  %-4s  %8s\n', 'Idx', 'Sym', 'q (e)');
fprintf('  %s\n', repmat('-', 1, 20));
for i = 1:numel(syms_use)
    fprintf('  %4d  %-4s  %+8.4f\n', i, syms_use{i}, q_use(i));
end
fprintf('  %s\n', repmat('-', 1, 20));
fprintf('  Sum = %+.5f e\n\n', sum(q_use));

% -------------------------------------------------------------------------
% Visualisation
% -------------------------------------------------------------------------
if do_plot
    % Load molecular geometry (needed for 3D label positions)
    mol = G16_structure(filename);

    % Consistency check
    if strcmp(mode, 'atom') && numel(q_use) ~= mol.Natoms
        warning('G16_charges: charge count (%d) does not match Natoms (%d)', ...
            numel(q_use), mol.Natoms);
    end

    % Render the CPK molecular structure
    [~, fname] = fileparts(filename);
    fig_title  = sprintf('%s — %s charges (%s)', ...
        strrep(fname,'_','\_'), charge_type, mode);

    fig = figure('Color', 'white', 'Name', ...
        sprintf('%s charges', charge_type), 'NumberTitle', 'off');
    ax = axes('Parent', fig);

    G16_draw_molecule(mol, 'Ax', ax, 'AtomScale', atom_scale, ...
        'BondTol', bond_tol, 'ShowLabels', false, ...
        'ShowLegend', true, 'Title', fig_title);

    % Set up colour scale
    q_max = max(abs(q_use));
    if q_max == 0, q_max = 1; end

    % Determine 3D coordinates for label placement
    if strcmp(mode, 'atom')
        xyz_use = mol.xyz;
    else
        % In 'heavy' mode, place labels on heavy atom positions only
        is_heavy = ~strcmp(mol.symbols, 'H');
        xyz_use  = mol.xyz(is_heavy, :);
        % Safety fallback if atom counts do not match
        if size(xyz_use,1) ~= numel(q_use)
            xyz_use = mol.xyz(1:numel(q_use), :);
        end
    end

    % Add charge labels to the figure
    for i = 1:numel(q_use)
        if abs(q_use(i)) < thr, continue; end

        % Assign text colour from the RdBu scale
        if strcmpi(cscale, 'RdBu')
            t = q_use(i) / q_max;   % in [-1, 1]
            clr = charge_color(t);
        else
            clr = [0 0 0];
        end

        % Offset label slightly above the atom centre
        r_off = atom_scale * 0.8 + 0.3;
        tx = xyz_use(i,1);
        ty = xyz_use(i,2);
        tz = xyz_use(i,3) + r_off;

        lbl = sprintf('%+.3f', q_use(i));
        text(ax, tx, ty, tz, lbl, ...
             'FontSize',            fsize, ...
             'Color',               clr, ...
             'FontWeight',          'bold', ...
             'HorizontalAlignment', 'center', ...
             'VerticalAlignment',   'bottom', ...
             'Interpreter',         'none', ...
             'HandleVisibility',    'off');
    end

    % Add colourbar to figure
    if strcmpi(cscale, 'RdBu')
        add_charge_colorbar(ax, q_max);
    end

    rotate3d(ax, 'on');
end

end  % G16_charges


% =========================================================================
%  RdBu colour: blue (negative) -> white (zero) -> red (positive)
% =========================================================================
function clr = charge_color(t)
% t in [-1, 1]
t = max(-1, min(1, t));
if t >= 0
    % positive: interpolate white → red
    clr = [1, 1-t, 1-t];
else
    % negative: interpolate blue → white
    clr = [1+t, 1+t, 1];
end
% Darken slightly to improve readability against the light background
clr = clr * 0.82;
end


% =========================================================================
%  Colour bar orizzontale in basso
% =========================================================================
function add_charge_colorbar(ax, q_max)
% Manually create a colourbar using a dedicated axes object
fig = ax.Parent;

% Position the colourbar axes at the bottom
cb_ax = axes('Parent', fig, ...
             'Position', [0.15 0.03 0.70 0.025], ...
             'XLim', [-q_max, q_max], ...
             'YLim', [0 1]);

% Fill the colourbar with the RdBu gradient
n = 256;
x_cb = linspace(-q_max, q_max, n);
for j = 1:n-1
    t = x_cb(j) / q_max;
    c = charge_color(t);
    patch(cb_ax, [x_cb(j) x_cb(j+1) x_cb(j+1) x_cb(j)], ...
                 [0 0 1 1], c, 'EdgeColor', 'none');
end

% Asse x
set(cb_ax, 'YTick', [], 'XAxisLocation', 'bottom', ...
           'FontSize', 7, 'Box', 'on');
xlabel(cb_ax, 'charge (e)', 'FontSize', 8);

% Draw a vertical line at q=0
line(cb_ax, [0 0], [0 1], 'Color', 'k', 'LineWidth', 0.5);
end
